﻿namespace GameConsole
{
    internal class CHAR_INFO
    {
    }
}